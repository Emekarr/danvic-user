export * from './schemas'
export * from './types'

export interface ApiError {
  code: string
  details?: unknown
}

export type ApiResponse<T> =
  | {
      success: true
      status: number
      message: string
      data: T
      error: null
    }
  | {
      success: false
      status: number
      message: string
      data: null
      error: ApiError
    }

export const apiSuccess = <T>(status: number, message: string, data: T): ApiResponse<T> => ({
  success: true,
  status,
  message,
  data,
  error: null,
})

export const apiError = (
  status: number,
  message: string,
  code: string,
  details?: unknown,
): ApiResponse<never> => ({
  success: false,
  status,
  message,
  data: null,
  error: details === undefined ? { code } : { code, details },
})

export const isApiResponse = <T>(value: unknown): value is ApiResponse<T> => {
  if (!value || typeof value !== 'object') return false
  const candidate = value as Partial<ApiResponse<T>>
  const hasBaseFields =
    typeof candidate.success === 'boolean' &&
    Number.isInteger(candidate.status) &&
    candidate.status! >= 100 &&
    candidate.status! <= 599 &&
    typeof candidate.message === 'string' &&
    'data' in candidate &&
    'error' in candidate
  if (!hasBaseFields) return false
  if (candidate.success) return candidate.error === null
  return (
    candidate.data === null &&
    typeof candidate.error === 'object' &&
    candidate.error !== null &&
    typeof candidate.error.code === 'string'
  )
}

export class ApiClientError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code: string,
    readonly details?: unknown,
  ) {
    super(message)
    this.name = 'ApiClientError'
  }
}

export async function apiFetch<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(apiUrl(path), {
    ...init,
    credentials: 'include',
    headers: {
      accept: 'application/json',
      ...(init?.body ? { 'content-type': 'application/json' } : {}),
      ...init?.headers,
    },
  })
  const payload = (await response.json().catch(() => null)) as unknown
  if (!isApiResponse<T>(payload)) {
    throw new ApiClientError(
      'The API returned an invalid response',
      response.status,
      'INVALID_API_RESPONSE',
    )
  }
  if (payload.status !== response.status) {
    throw new ApiClientError(
      'The API response status does not match the HTTP status',
      response.status,
      'INVALID_API_RESPONSE',
    )
  }
  if (!response.ok || !payload.success) {
    throw new ApiClientError(
      payload.message || 'The request could not be completed',
      response.status,
      payload.error?.code ?? 'REQUEST_FAILED',
      payload.error?.details,
    )
  }
  return payload.data
}

/**
 * Static frontends use the Express API directly. The legacy `/api/*` path is
 * retained at call sites, but is resolved to the app-specific compatibility
 * endpoint when a public backend URL is configured.
 */
export const apiUrl = (path: string): string => {
  const baseUrl = process.env.NEXT_PUBLIC_BACKEND_API_URL?.replace(/\/$/, '')
  const app = process.env.NEXT_PUBLIC_DANVIC_APP
  if (!baseUrl || !app || !path?.startsWith('/api/')) return path
  return `${baseUrl}/api/${app}/${path.slice('/api/'.length)}`
}
